<?php
/**
 * @package WptUsers
 */
/**
 * Plugin Name: Wpt Users
 * Plugin URI: https://w-prothemes.com/plugin
 * Description: User management sytem for wordpress
 * Version: 1.0.0
 * Author Name: MD AL AMIN ISLAM
 * Author URI: https://w-prothemes.com
 * License: GPLv3 or later
 * Text Domain: wpt-users
 */

 // If this file is called directly, abort!!!
 defined( 'ABSPATH' ) or die( 'Hey, you can not access this file, you silly human' );

 // Require once the composer autoloader
if( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ){
    require_once (dirname( __FILE__ ) . '/vendor/autoload.php' );
}

// Activation hooks
function wpt_user_activate(){
    Inc\Base\Activate::activate();
}
register_activation_hook( __FILE__, 'wpt_user_activate' );

// Dactivation hooks
function wpt_user_deactivate(){
    Inc\Base\Deactivate::deactivate();
}
register_deactivation_hook( __FILE__, 'wpt_user_deactivate' );

// Initialize all the core classes
if( class_exists( 'Inc\\Init' ) ){
    Inc\Init::register_services();
}
