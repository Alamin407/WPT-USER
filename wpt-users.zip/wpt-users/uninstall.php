<?php
/**
 * Triger this file on Plugin Uninstall
 * 
 * @package WptUsers
 */
if( ! defined( 'WP_UNINSTALL_PLUGIN' ) ){
    die;
}

// Access the db
global $wpdb;
$wpdb->query( "DELETE FROM wp_posts WHERE post_type = 'book'" );
$wpdb->query( "DELETE FROM wp_postmeta WHERE post_id NOT IN ( SELECT id if FROM wp_posts )" );
$wpdb->query( "DELETE FROM wp_term_relationships WHERE object_id NOT IN ( SELECT id if FROM wp_posts )" );