(function( $ ) {
    // "use strict";
    
    $( window ).load( function(){
        $( '.wpt-log-out a' ).click(function(){
            $( '.wpt-popup' ).addClass( 'wpt-slide' );
        });
    } );
})(jQuery);
