<?php
/**
 * @package WptUsers
 */

 namespace Inc;

 final class Init{
    /**
     * Store all the classes in an array
     * @return arry full list of classes
     */
    public static function get_services(){
        return [
            Pages\Admin::class,
            Base\Enqueue::class,
            Base\SettingsLinks::class,
            Base\CustomRegister::class,
            Base\CustomLogin::class,
            Base\CustomProfilePage::class,
            Base\VisaStatus::class,
            Base\CustomLogoutPage::class,
            Base\AirTicket::class,
        ];
    }
    /**
     * Loop through all the classes, initilize them
     * and call the register method if it exists
     * @return
     */
    public static function register_services() {
        foreach( self::get_services() as $class ){
            $services = self::instantiate( $class );

            if( method_exists( $services, 'register' ) ){
                $services->register();
            }
        }
    }
    /**
     * Initialize the class
     * @param class $class class from the services array
     * @return class instance new instance of the class
     */
    private static function instantiate($class){
        $services = new $class;

        return $services;
    }
 }


// use Inc\Base\Activate;
// use Inc\Base\Deactivate;

//  if( ! class_exists( 'Wpt_Users' ) ){
//     class Wpt_Users{
//         public $plugin;

//         public function __construct()
//         {
//             $this->plugin = plugin_basename(__FILE__);
//         }

//         public function wpt_register(){
//             add_action( 'admin_enqueue_scripts', [ $this, 'wpt_enqueue_scripts' ] );

//             add_action( 'admin_menu', [ $this, 'add_admin_page' ] );

//             add_filter( "plugin_action_links_$this->plugin", [ $this, 'settings_link' ] );
//         }

//         public function settings_link($links){
//             $settings_link = '<a href="admin.php?page=custom-applications">Settings</a>';

//             array_push( $links, $settings_link );

//             return $links;
//         }

//         public function add_admin_page(){
//             add_menu_page( 
//                 'Applications',
//                 'Applications',
//                 'manage_options', 
//                 'custom-applications',
//                 [ $this, 'custom_applications_page' ],
//                 'dashicons-id-alt',
//                 34
//                  );
//         }

//         public function custom_applications_page(){
//             require_once plugin_dir_path( __FILE__ ) . '/templates/wpt-users-admin.php';
//         }

//         protected function wpt_post_type(){
//             register_post_type( 'book', [ 'public' => true, 'label' => 'Books' ] );
//         }

//         public function wpt_enqueue_scripts(){
//             // Enqueue style
//             wp_enqueue_style( 'wpt-main-css', plugins_url('/assets/css/style.css', __FILE__) );
//             wp_enqueue_script( 'wpt-main-js', plugins_url('/assets/js/app.js', __FILE__) );
//         }

//         public function activate(){
//             Activate::activate();
//         }

//         public function deactivate(){
//             Deactivate::deactivate();
//         }
//     }

//     $wptusers = new Wpt_Users();
//     $wptusers->wpt_register();
//      // Activate
//     register_activation_hook( __FILE__, array( $wptusers, 'activate' ) );
//     // Deactivate
//     register_default_headers( __FILE__, array( $wptusers, 'deactivate' ) );
//  }