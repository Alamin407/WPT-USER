<?php
/**
 * @package WptUsers
 */

 namespace Inc\Pages;

 use \Inc\Base\BaseController;

 class Admin extends BaseController{
    public function register() {
        add_action( 'admin_menu', [ $this, 'add_admin_page' ] );
    }

   public function add_admin_page(){
      add_menu_page( 
         'Applications',
         'Applications',
         'manage_options', 
         'custom-applications',
         [ $this, 'custom_applications_page' ],
         'dashicons-id-alt',
         34
      );
   }

   public function custom_applications_page(){
      require_once $this->plugin_path . '/templates/wpt-users-admin.php';
   }


 }