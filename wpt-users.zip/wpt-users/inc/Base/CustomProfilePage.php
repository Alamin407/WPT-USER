<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;
use \Inc\Base\BaseController;

class CustomProfilePage extends BaseController{
    
    public function register(){
        add_shortcode( 'custom_profile_page', [ $this, 'custom_profile_page' ] );
        add_filter( 'show_admin_bar', [ $this, 'hide_wordpress_admin_bar' ] );
    }

    public function custom_profile_page(){
        ob_start();
        if( is_user_logged_in() ){
            $current_user = wp_get_current_user();
            require_once $this->plugin_path . '/templates/wpt-user-profile.php';
        }else{
            echo 'You must be logged in to view your profile.';
        }
        return ob_get_clean();
    }

    public function hide_wordpress_admin_bar(){
        if( !current_user_can( 'administrator' ) || !current_user_can( 'editor' ) ){
            return false;
        }
    }
}