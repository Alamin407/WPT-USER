<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;
use \Inc\Base\BaseController;

class CustomLogin extends BaseController{
    public function register(){
        add_shortcode( 'custom_login_form', [ $this, 'custom_login_form' ] );
        add_action( 'init', [ $this, 'custom_login_process' ] );
        
    }

    public function custom_login_form(){
        ob_start();
        require_once $this->plugin_path . '/templates/wpt-user-login.php';
        return ob_get_clean();
    }

    public function custom_login_process(){
        if( isset( $_POST[ 'login_submit' ] ) ){
            $login_username = sanitize_user($_POST['login_username']);
            $login_password = $_POST['login_password'];
            
            $user = wp_authenticate($login_username, $login_password);
            
            if (!is_wp_error($user)) {
                wp_set_auth_cookie($user->ID, true);
                echo 'Login successful. Welcome, ' . $user->display_name . '!';
            } else {
                echo 'Login failed. Please try again.';
            }

            if (is_wp_error($user)) {
                $error_message = $user->get_error_message();
                add_action('login_form', array($this, 'display_login_error'));
            } else {
                wp_redirect(home_url('/my-account/'));
                exit;
            }
        }
    }
}