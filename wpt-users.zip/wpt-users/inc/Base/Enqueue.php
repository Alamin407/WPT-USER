<?php
/**
 * @package WptUsers
 */

 namespace Inc\Base;
 use \Inc\Base\BaseController;

 class Enqueue extends BaseController{

    public function register() {
        // Admin Style
        add_action( 'admin_enqueue_scripts', [ $this, 'wpt_admin_enqueue_scripts' ] );

        // Public Style
        add_action( 'wp_enqueue_scripts', [ $this, 'wpt_public_enqueue_scripts' ] );
    }

    public function wpt_admin_enqueue_scripts(){
        // Enqueue style
        wp_enqueue_style( 'wpt-main-css', $this->plugin_url . 'assets/css/style.css' );
        
        wp_enqueue_script( 'wpt-main-js', $this->plugin_url . 'assets/js/app.js', [ 'jquery' ], false, false  );
    }

    public function wpt_public_enqueue_scripts(){
        // Enqueue style
        wp_enqueue_style( 'wpt-main-css', $this->plugin_url . 'assets/css/style.css' );
        
        wp_enqueue_script( 'wpt-main-js', $this->plugin_url . 'assets/js/app.js', [ 'jquery' ], false, false  );
    }
 }