<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;

class AirTicket{
    public function register(){
        add_shortcode( 'air_ticket', [ $this, 'air_ticket' ] );
    }

    public function air_ticket(){
        ob_start();
        if( is_user_logged_in() ){
            $current_user = wp_get_current_user();
        ?>
        <div class="wpt-user-info">
            <h3>Welcome, <?php echo $current_user->first_name; ?></h3>
            <p>Email: <?php echo $current_user->user_email; ?></p>
        </div>
        <div class="wpt-ap-wrap">
            <div class="wpt-ap-nav">
                <a href="<?php echo esc_url(home_url( '/my-account' )); ?>" id="appbtn" class="applybtn">Apply</a>
                <a href="<?php echo esc_url(home_url( '/visa-status' )); ?>" id="appbtn" class="vistatus">Visa Status</a>
                <a href="<?php echo esc_url(home_url( '/air-ticket' )); ?>" id="appbtn" class="artikt active">Air Ticket</a>
            </div>
            <div class="wpt-ap-content">
                <div class="wpt-ap-form wpt-air">
                    <div class="info">
                        <h2>Please Contact your agent for more informaton, Thank you!</h2>
                    </div>
                </div>
            </div>
        </div>
        <?php
        }else{
            echo 'You must be logged in to view your profile. <a href="http://localhost/wp-dev/login/">Login</a>';
        }
        return ob_get_clean();
    }
}