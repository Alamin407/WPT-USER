<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;
class CustomLogoutPage{
    public function register(){
        add_shortcode('custom_logout_page', [$this, 'custom_logout_page']);
    }

    public function custom_logout_page( $atts ){
        return '<div class="log-popup">
            <div class="wpt-popup">
                <h3 class="logtext">Are you sure you want to logout?</h3>
                <a href="' . wp_logout_url( home_url() ) . '" class="wpt-btn">Logout</a>
            </div>
        </div>';
    }
}