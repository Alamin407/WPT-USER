<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;
use \Inc\Base\BaseController;

class CustomRegister extends BaseController {
    public function register(){
        add_shortcode( 'custom_registration_form', [ $this, 'custom_registration_form' ] );
        add_action( 'init', [ $this, 'custom_registration_process' ] );
    }

    public function custom_registration_form(){
        ob_start();
            require_once $this->plugin_path . '/templates/wpt-user-register.php';
        return ob_get_clean();
    }

    public function custom_registration_process(){
        if (isset($_POST['submit'])) {
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $username = sanitize_user($_POST['username']);
            $email = sanitize_email($_POST['email']);
            $password = $_POST['password'];
            
            $user_id = wp_create_user( $username, $password, $email);
            
            if (!is_wp_error($user_id)) {
                update_user_meta($user_id, 'first_name', $first_name);
                update_user_meta($user_id, 'last_name', $last_name);
                echo 'Registration successful. Please <a href="' . wp_redirect(home_url('/login')); // Redirect to login page
                exit;
            } else {
                echo 'Registration failed. Please try again.';
            }
        }
    }
}