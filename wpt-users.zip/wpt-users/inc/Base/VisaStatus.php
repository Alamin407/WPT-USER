<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;

class VisaStatus extends BaseController{
    
    public function register(){
        add_shortcode( 'visa_status', [ $this, 'visa_status' ] );
    }

    public function visa_status(){
        ob_start();
        if( is_user_logged_in() ){
            $current_user = wp_get_current_user();
            $error = ""; 
            require_once $this->plugin_path . '/templates/wpt-visa-status.php';
        }else{
            echo 'You must be logged in to view your profile. <a href="http://localhost/wp-dev/login/">Login</a>';
        }
        return ob_get_clean();
    }
}