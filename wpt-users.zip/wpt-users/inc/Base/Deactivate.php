<?php
/**
 * @package WptUsers
 */
namespace Inc\Base;
 class Deactivate{
    public static function deactivate(){
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_applications';
        $sql = "DROP TABLE IF EXISTS $table_name";
        $wpdb->query( $sql );
        flush_rewrite_rules();
    }
 }