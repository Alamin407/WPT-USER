<div class="wpt-register-form">
    <div class="wpt-title">
        <h3>Welcome to Guidance</h3>
    </div>
    <form id="custom-registration-form" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="post">
        <div class="wpt-form-group">
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" class="wpt-form-control" id="first_name" required placeholder="First Name">
        </div>
        <div class="wpt-form-group">
            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" class="wpt-form-control" id="last_name" required placeholder="Last Name">
        </div>
        <div class="wpt-form-group">
            <label for="username">Username:</label>
            <input type="text" name="username" class="wpt-form-control" id="username" required placeholder="Username">
        </div>
        <div class="wpt-form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" class="wpt-form-control" id="email" required placeholder="Email">
        </div>
        <div class="wpt-form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" class="wpt-form-control" id="password" required placeholder="Password">
        </div>
        <div class="wpt-form-group">
            <div class="wpt-register">
                <input type="submit" name="submit" class="wpt-btn" value="Create Account">
            </div>
        </div>
    </form>
</div>