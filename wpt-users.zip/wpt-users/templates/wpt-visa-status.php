<div class="wpt-user-info">
    <h3 class="user-name">Welcome, <?php echo $current_user->first_name; ?></h3>
    <p class="user-email">Email: <?php echo $current_user->user_email; ?></p>
</div>
<div class="wpt-ap-wrap">
    <div class="wpt-ap-nav">
        <a href="<?php echo esc_url(home_url( '/my-account' )); ?>" id="appbtn" class="applybtn">Apply</a>
        <a href="<?php echo esc_url(home_url( '/visa-status' )); ?>" id="appbtn" class="vistatus active">Visa Status</a>
        <a href="<?php echo esc_url(home_url( '/air-ticket' )); ?>" id="appbtn" class="artikt">Air Ticket</a>
    </div>
    <div class="wpt-ap-content">
    <?php
            if( isset( $_POST['visa_status_check_submit'] ) ){
                $application_code = intval($_POST[ 'application_id' ]);   

                if( ! is_numeric($application_code) ){
                    echo '<p class="error">Numbr should enter your visa number!</p>';
                } elseif ( strlen($application_code) < 9 ) {
                    echo '<p class="error">Numbr should be 9 character!</p>';
                }elseif ( strlen($application_code) > 9 ) {
                    echo '<p class="error">Numbr should be 9 character!</p>';
                }else if( strlen($application_code) == 9){
                    $application_id = $current_user->ID;

                    // Query the database to fetch the status based on the application ID
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'custom_applications';
                    
                    $visa_status = $wpdb->get_var(
                        $wpdb->prepare("SELECT visa_status FROM $table_name WHERE user_id = %d", $application_id)
                    );

                    $visa_code = $wpdb->get_var(
                        $wpdb->prepare("SELECT apply_code FROM $table_name WHERE user_id = %d", $current_user->ID)
                    );

                    if ($application_code == $visa_code ) {
                        echo '<p class="status">Your Visa Application Status: <strong>' . ucfirst($visa_status) . '</strong></p>';
                    } else {
                        $error = "Invalid Application Code";
                    }
                }
            }
        ?>
        <div class="wpt-ap-form wpt-status">
            <form id="visa-status-check-form" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="post">
                <div class="wpt-form-group">
                    <label for="application_id">Enter your application Code</label>
                    <input type="text" name="application_id" id="application_id" class="wpt-form-control" required placeholder="002255778">
                    <p class="error"><?php echo $error; ?></p>
                </div>
                <div class="wpt-form-group">
                    <input type="submit" class="wpt-btn" name="visa_status_check_submit" value="Check Status">
                </div>
            </form>
        </div>
    </div>
</div>