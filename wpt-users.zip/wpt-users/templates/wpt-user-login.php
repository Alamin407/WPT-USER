<div class="wpt-user-login">
    <div class="wpt-title">
        <h3>Sign In</h3>
        <p>Sign in and apply your visa application</p>
    </div>
    <form id="custom-login-form" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="post">
        <div class="wpt-form-group">
            <label for="login_username">Username:</label>
            <input type="text" class="wpt-form-control" name="login_username" id="login_username" required>
        </div>
        <div class="wpt-form-group">
            <label for="login_password">Password:</label>
            <input type="password" class="wpt-form-control" name="login_password" id="login_password" required>
        </div>
        <div class="wpt-form-group">
            <div class="wpt-register">
                <input type="submit" class="wpt-btn" name="login_submit" value="Sign In">
            </div>
        </div>
    </form>
</div>