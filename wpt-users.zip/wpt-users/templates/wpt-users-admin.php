<h1 class="dashboard">Applications</h1>
<?php

use Elementor\Modules\WpCli\Update;

    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_applications';

    // Update status if "Manage" action is submitted
    if( isset( $_POST[ 'manage_submit' ] ) ){
        $application_id = intval( $_POST[ 'application_id' ] );
        $new_status = sanitize_text_field( $_POST[ 'new_status' ] );

        if( $new_status === 'completed' || $new_status === 'pending' ){
            $wpdb->update( $table_name, array( 'visa_status' => $new_status ), array( 'id' => $application_id ) );
        }
    }

    // Pagination
    $items_per_page = 10;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $items_per_page;

    $applications = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT $offset, $items_per_page");
    $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");

    $total_pages = ceil($total_items / $items_per_page);

    ?>
    <div class="wrap">
        <table class="wp-list-table widefat striped wpt-table-list">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Visa ID</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Manage</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($applications as $application) {
                    echo '<tr>';
                    echo '<td>' . $application->user_full_name . '</td>';
                    echo '<td>' . $application->apply_code . '</td>';
                    echo '<td>' . $application->type . '</td>';
                    echo '<td>' . $application->visa_status . '</td>';
                    echo '<td>' . $application->created_at . '</td>';
                    echo '<td>';
                    if ($application->visa_status === 'pending') {
                        echo '<form method="post" action="" class="update-form">';
                        echo '<input type="hidden" name="application_id" value="' . $application->id . '">';
                        echo '<input type="hidden" name="user_id" value="' . $application->user_id . '">';
                        echo '<select name="new_status">';
                        echo '<option value="completed">Completed</option>';
                        echo '</select>';
                        echo '<input type="submit" name="manage_submit" value="Update" class="wpt-btn">';
                        echo '</form>';
                    } else {
                        echo '<form method="post" action="" class="update-form">';
                        echo '<input type="hidden" name="application_id" value="' . $application->id . '">';
                        echo '<input type="hidden" name="user_id" value="' . $application->user_id . '">';
                        echo '<select name="new_status">';
                        echo '<option value="pending">Pending</option>';
                        echo '</select>';
                        echo '<input type="submit" name="manage_submit" value="Update" class="wpt-btn">';
                        echo '</form>';
                    }
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
        
        <!-- Pagination links -->
        <?php
        if ($total_pages > 1) {
            echo '<div class="tablenav">';
            echo '<div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
                'total' => $total_pages,
                'current' => $current_page
            ));
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
    <?php

