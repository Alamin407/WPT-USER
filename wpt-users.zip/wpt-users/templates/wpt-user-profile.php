<div class="wpt-user-info">
    <h3 class="user-name">Welcome, <?php echo $current_user->first_name; ?></h3>
    <p class="user-email">Email: <?php echo $current_user->user_email; ?></p>
</div>
<div class="wpt-ap-wrap">
    <div class="wpt-ap-nav">
        <a href="<?php esc_url(home_url( '/my-account' )); ?>" id="appbtn" class="applybtn active">Apply</a>
        <a href="<?php echo esc_url(home_url( '/visa-status' )); ?>" id="appbtn" class="vistatus">Visa Status</a>
        <a href="<?php echo esc_url(home_url( '/air-ticket' )); ?>" id="appbtn" class="artikt">Air Ticket</a>
    </div>
    <div class="wpt-ap-content">
        <?php
            global $wpdb;
            $table_name = $wpdb->prefix . 'custom_applications';
            $existing_application = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d AND type = 'visa'", $current_user->ID)
            );
                $error = "";
            $user_has_application = !empty($existing_application);

            if( $user_has_application ){
                echo '<p class="submited">Application already submited. Please check your visa status!</p>';
            }else{
                if( isset( $_POST[ 'visa_apply_submit' ] ) ){
                    $application_code = sanitize_text_field($_POST[ 'apply' ]);
                    $full_name = sanitize_text_field($_POST[ 'full_name' ]);
                    if( !is_numeric( $application_code )){
                        $error = "Invalied Coede! Value must be 9 Charcter";
                    } elseif (strlen($application_code) > 9 || strlen($application_code) < 9) {
                        $error = "Invalied Coede! Value must be 9 Charcter";
                    }elseif (! empty( $application_code )) {
                        $data = array(
                            'user_id' => get_current_user_id(),
                            'user_full_name' => $full_name,
                            'type' => 'visa',
                            'apply_code' => $application_code,
                            'visa_status' => 'pending',
                            'created_at' => current_time('mysql')
                        );
                        $wpdb->insert( $table_name, $data );
                        echo '<p class="success">Application Submited Successfully</p>';
                    }    
                }
            ?>
            <div class="wpt-ap-form wpt-apply">
                <form id="visa-apply-form" action="" method="post">
                    <div class="wpt-form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" name="full_name" id="full_name" required placeholder="Full Name">
                    </div>
                    <div class="wpt-form-group">
                        <label for="apply">Application Code</label>
                        <input type="text" name="apply" id="apply" required placeholder="002255778">
                        <p class="error"><?php echo $error ?></p>
                    </div>
                    <div class="wpt-form-group">
                        <input type="submit" class="wpt-btn" name="visa_apply_submit" value="Apply">
                    </div>
                </form>
            </div>
        </div>
    <?php } ?>
</div>